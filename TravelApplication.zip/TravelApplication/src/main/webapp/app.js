
var app = angular.module("TravelCityManagement",  ['smart-table']);

//Controller Part
app.controller("TravelCityController", function($scope, $http) {


	$scope.countries = [];
	$scope.countryForm = {
			City : "",
			Country : "",
			Attractions : "",
			Visited:""
	};

	//Now load the data from server
	_refreshData();

	
	$scope.visitChange= function(country){
		$http({
			method : "PUT",
			url : 'rest/city',
			data : angular.toJson(country),
			headers : {
			'Content-Type' : 'application/json'
		}
		}).then(_successUPD, _error );
		
	}
	//HTTP POST method for add city 

	$scope.submitCity = function() {
		if($scope.countryForm.Attractions)
			$scope.countryForm.Attractions = $scope.countryForm.Attractions.split(',');
		else
			$scope.countryForm.Attractions=[];

		$http({
			method : "POST",
			url : 'rest/city',
			data : angular.toJson($scope.countryForm),
			headers : {
			'Content-Type' : 'application/json'
		}
		}).then(_successADD, _error );
	};         

	/* Private Methods */
	//HTTP GET- retrieve the cities from the server
	function _refreshData() {
		$http({
			method : 'GET',
			url : 'http://localhost:8080/TravelApp-0.0.1-SNAPSHOT/rest/city'
		}).then(function successCallback(response) {
			$scope.countries = response.data;
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	}

	function _successUPD(response) {

	}
	function _success(response) {
			_refreshData();
			_clearFormData();
	}
	function _successADD(response) {
		if(response.data)
		{
			_refreshData();
			_clearFormData();
		}
		else
			alert("Fail cannot add this city item!")
}
	function _error(response) {
		console.log(response.statusText);
	}

	//Clear the form
	function _clearFormData() {
		$scope.countryForm.City = "";
		$scope.countryForm.Country = "";
		$scope.countryForm.Attractions = "";
		$scope.countryForm.Visited = "";                
	};
});
