agGrid.initialiseAgGridWithAngular1(angular);



var fileBrowserModule = angular.module('basic', ['agGrid']);


fileBrowserModule.controller('basicController', function($scope,$http) {
	
	  var columnDefs = [
	                    {headerName: "City", field: "City", width: 150},
	                    {headerName: "Country", field: "Country", width: 150},
	                    {headerName: "Attraction", field: "Attractions", width: 200},
	                    {headerName: "Visited", field: "Visited", width: 100}
	                ];
	    $scope.gridOptions = {
	            columnDefs: columnDefs,
	            rowData: null,
	            angularCompileRows: true
	        };
	    

	    
//	    $http.get("travel.json")
//	    $http.get("/get/travel")
//        .then(function(res){
//            $scope.gridOptions.api.setRowData(res.data);
//        });

	    $http.get('/travel/dest')
	    .success(function(res) {
	      
	      console.log("ok");
	    })
	    .error(function(err) {
	      alert('Error! Something went wrong');
	    });
	
	
});
