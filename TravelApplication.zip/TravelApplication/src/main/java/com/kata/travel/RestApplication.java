package com.kata.travel;

import java.io.File;
import java.io.IOException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
@Path("TravelApp-0.0.1-SNAPSHOT/rest")
public class RestApplication extends Application {
	public static void main(String[] args) {
		
		System.out.println("ILR");
	}
	
	
	@GET
	@Path("/get/travel/{id}")
	@Produces("text/json")
	public Response getMsg(@PathParam("id") String id)
	{
		String output = "Jersey say : " + id;
		return Response.status(200).entity(output).build();
	}
	//Endpoints
	
	@GET
	@Path("/get/work")
	public Response getWorkingDir()
	{
		String work="";
		try {
			work = new File(".").getCanonicalPath();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return Response.status(200).entity(work).build();
	}

}
